32 rooms; four cameras; times 0 and 1. PNG/WebP channels are display previews, not float32 ground truth.
world_from_view stores columns; view forward is -Z. The architecture file covers all 512 audited seeds.
Six modes include production GPU co-visibility. Exact uint16 masks and uint8 validity PNGs are in visibility-masks.zip.
No temporal flow or continuous video was captured in this cohort.
