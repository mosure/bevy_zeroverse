32 rooms; four cameras; times 0 and 1. PNG/WebP channels are display previews, not float32 ground truth.
world_from_view stores columns; view forward is -Z. The architecture file covers all 512 audited seeds.
No temporal flow, co-visibility or video was captured in this cohort.
